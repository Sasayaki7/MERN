import { createContext } from "react";

const ProductFormContext = createContext();


export default ProductFormContext;