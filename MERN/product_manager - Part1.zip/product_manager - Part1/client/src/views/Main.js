import React from 'react';
import ProductForm from '../components/productForm';

const Main = props =>{

    return (
        <>
            <ProductForm/>
        </>
    )
}

export default Main;